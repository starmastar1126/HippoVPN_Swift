//
//  PacketTunnelProvider.h
//  PacketTunnel
//
//  Created by Viet Anh on 4/7/20.
//  Copyright © 2020 zorro. All rights reserved.
//

#import <NetworkExtension/NetworkExtension.h>

@interface PacketTunnelProvider : NEPacketTunnelProvider

@end
