//
//  main.m
//  IKEv2_Demo
//
//  Created by zqqf16 on 16/3/16.
//  Copyright © 2016年 zqqf16. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
