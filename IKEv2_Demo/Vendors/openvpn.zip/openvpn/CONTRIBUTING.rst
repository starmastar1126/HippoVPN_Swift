Contributing to OpenVPN 3
=========================

Patches can be sent as GitHub pull requests.

Note that by contributing to the OpenVPN 3 project you accept the Contributor
License Agreement described in `CLA.rst <CLA.rst>`_.
