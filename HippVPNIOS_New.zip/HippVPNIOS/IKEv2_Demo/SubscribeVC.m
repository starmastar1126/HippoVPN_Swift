//
//  SubscribeVC.m
//  HippoVPN
//
//  Created by xiao long on 2020/3/31.
//  Copyright © 2020 zorro. All rights reserved.
//

#import "SubscribeVC.h"
#import "HomeViewController.h"

@interface SubscribeVC ()


@end

@implementation SubscribeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)onClose:(UIButton *)sender {
    HomeViewController *homeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeVCID"];
    [self.navigationController pushViewController:homeVC animated:YES];
}

- (IBAction)onSubscribe:(UIButton *)sender {
    [self fetchAvailableProducts];
//    dispatch_async(dispatch_get_main_queue(), ^{
//    });
}

- (BOOL)canMakePurchases {
   return [SKPaymentQueue canMakePayments];
}

- (void)purchaseMyProduct:(SKProduct*)product {
   if ([self canMakePurchases]) {
      SKPayment *payment = [SKPayment paymentWithProduct:product];
      [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
      [[SKPaymentQueue defaultQueue] addPayment:payment];
   } else {
      UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:
      @"Purchases are disabled in your device" message:nil delegate:
      self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
      [alertView show];
   }
}

-(void)fetchAvailableProducts {
   NSSet *productIdentifiers = [NSSet setWithObjects:@"Hippo",nil];
   productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:productIdentifiers];
   productsRequest.delegate = self;
   [productsRequest start];
}

#pragma mark StoreKit Delegate

-(void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
   for (SKPaymentTransaction *transaction in transactions) {
      switch (transaction.transactionState) {
         case SKPaymentTransactionStatePurchasing:
            NSLog(@"Purchasing");
         break;
         
         case SKPaymentTransactionStatePurchased:
            NSLog(@"Purchased ");
            [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool:YES] forKey:@"isSubbed"];
            [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
         break;
            
         case SKPaymentTransactionStateRestored:
            NSLog(@"Restored ");
            [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool:YES] forKey:@"isSubbed"];
            [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
         break;
            
         case SKPaymentTransactionStateFailed:
            NSLog(@"Purchase failed ");
            [[NSUserDefaults standardUserDefaults] setObject: [NSNumber numberWithBool:NO] forKey:@"isSubbed"];
              break;
          default:
              break;
      }
   }
}

-(void)productsRequest:(SKProductsRequest *)request
didReceiveResponse:(SKProductsResponse *)response {
   SKProduct *validProduct = nil;
   int count = [response.products count];
   
   if (count>0) {
      validProducts = response.products;
      validProduct = [response.products objectAtIndex:0];
      [self purchaseMyProduct:validProduct];
      
       NSLog(@"Product Title: %@",validProduct.localizedTitle);
       NSLog(@"Product Desc: %@",validProduct.localizedDescription);
       NSLog(@"Product Price: %@",validProduct.price);
   } else {
   }
   
//   [activityIndicatorView stopAnimating];
}

@end
