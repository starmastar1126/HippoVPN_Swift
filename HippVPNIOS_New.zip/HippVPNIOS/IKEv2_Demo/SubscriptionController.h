//
//  SubscriptionController.h
//  HippoVPN
//
//  Created by Viet Anh on 3/29/20.
//  Copyright © 2020 zorro. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubscriptionController : UIViewController
+ (void) setIndexChoose:(int) choose;
@end

NS_ASSUME_NONNULL_END
