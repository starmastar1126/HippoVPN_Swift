//
//  MyNavigationViewController.h
//  VPN Pro
//
//  Created by Vũ Thanh Tùng on 4/27/18.
//  Copyright © 2018 HUST. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SWRevealViewController.h"
@interface MyNavigationViewController : UITableViewController
@end
